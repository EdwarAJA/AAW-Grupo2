package pe.edu.upc.avi_aplicaction;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AviAplicactionApplicationTests {

	@Test
	void contextLoads() {
	}

}
