package pe.edu.upc.avi_aplicaction;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AviAplicactionApplication {

	public static void main(String[] args) {
		SpringApplication.run(AviAplicactionApplication.class, args);
	}

}
