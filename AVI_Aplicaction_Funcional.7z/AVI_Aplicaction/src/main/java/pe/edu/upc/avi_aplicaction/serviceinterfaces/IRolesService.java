package pe.edu.upc.avi_aplicaction.serviceinterfaces;

import pe.edu.upc.avi_aplicaction.entities.roles;

import java.util.List;

public interface IRolesService {
    public List<roles> list();
}
