package pe.edu.upc.avi_aplicaction.dtos;

public class RolesDTO {

    private int Id_Roles;
    private String Tipo;

    public int getId_Roles() {
        return Id_Roles;
    }

    public void setId_Roles(int id_Roles) {
        Id_Roles = id_Roles;
    }

    public String getTipo() {
        return Tipo;
    }

    public void setTipo(String tipo) {
        Tipo = tipo;
    }
}
